import Alllinks from './Alllinks';
import { useState } from "react";
import axios from 'axios';
import { render } from '@testing-library/react';

function Main() {
    const [imageUpload, setImageUpload] = useState(null);
   
    const config = {
        headers: { Authorization: `Bearer ${"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjYyNzQxMTI0LCJqdGkiOiI5NzZhMDJiMzVlMWI0ZjIxOTAyMDlhODA0OTY3MWQ5NyIsInVzZXJfaWQiOjF9.HmP8Yw1y8uqZYl-oGrduLhFx2CrtFcnMz2yBSOUcqRw"}` }
    };
    const uploadFile = () => {
      if (imageUpload == null) return;
      console.log(imageUpload);
      const formData = new FormData();
      formData.append("file",imageUpload,imageUpload.name);
   axios.post("http://127.0.0.1:8888/api/jsonview/",formData,config).then(console.log).catch(console.log);;
    
     
    };
  
    async function RetrieveALL(){
        let res= await fetch("http://127.0.0.1:8888/api/jsonview");
        let data=await res.json();
        console.log(data);
        render(

            <div>
            <div className="col-md-8 m">
              
           <table className="table table-hover table-bordered">
             <thead>
               <tr>
                 <th scope="col">User ID</th>
                 <th scope="col">Title</th>
                 <th scope="col">Body</th>
               </tr>
             </thead>
             {data.length > 0 && data ?
             <tbody>
                 
               {data.map((data, index) => {
                 return (
                   <tr key={index}>
                     <th scope="row">{data.userId}</th>
                     <td>{data.title}</td>
                     <td>{data.body}</td>
                   </tr>
                 );
               })}
               
             </tbody>
            :<h2>No data</h2>}
           </table>
         </div>
        </div>
        )
      }
  
    return (
      <div className="App">
        <input
          type="file"
          onChange={(event) => {
            setImageUpload(event.target.files[0]);
          }}
        />
        <button onClick={uploadFile}> Upload Image</button>
        
        <button onClick={RetrieveALL}> RetrieveData</button>
        
      </div>
    );
  }
  
  export default Main;
  

import './App.css';

import Login from './login';

import {BrowserRouter as Router,Route,Routes } from 'react-router-dom';
import Main from './Main';

function App() {
 
  return (

<Router>
  <Routes>
<Route path="/" element={<Login/>}/>

<Route path="/Main" element={<Main/>}/>
  </Routes>
</Router>
   
  );
}

export default App;
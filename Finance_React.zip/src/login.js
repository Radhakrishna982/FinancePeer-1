import React, { useState } from "react";

import "./loginform.css";


import { useNavigate } from "react-router-dom";

const Login = (props) => {
    const navigate = useNavigate();

    const [username,setUsername]=useState("");
    const [password,setPassword]=useState("");
async function funclog()
{  
    console.log(username,password);

    let item={username,password};
    let res= await fetch("http://127.0.0.1:8888/api/token-auth/",
    {
        method:"POST",
        headers:{
            "Content-Type":"application/json",
            "Accept":"application/json"
        },
        body:JSON.stringify(item)

    });
   
    res= await res.json();
 navigate("/Main");
   
   
}
    return (
        <div >
            <h1>Login Page</h1>
            <div className= "col-sm-6 offset-sm-3">
            <input type="text" placeholder="username" onChange={
                (e)=>setUsername(e.target.value)
            }/>
            <input type="password" placeholder="password" onChange={
                (e)=>setPassword(e.target.value)
            }/>
<br></br>
          <button className="btn-btn-primary"onClick={funclog}>Login</button>

          </div>

        </div>
    )
}

export default Login;
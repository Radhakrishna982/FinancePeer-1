from django.contrib import admin
from .models import jsonData
# Register your models here.

admin.site.register(jsonData)
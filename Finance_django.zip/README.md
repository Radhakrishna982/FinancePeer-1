To Run Django Project
 Python 3.8.x
 Django
 
Trigger API
Create venvironment and activate the virtual env
Install the requirements
pip install -r requirements.txt
Run the server
python manage.py runserver 8888
